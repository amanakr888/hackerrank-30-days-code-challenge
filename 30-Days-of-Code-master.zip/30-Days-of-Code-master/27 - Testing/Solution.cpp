#include <iostream>

using namespace std;

int main() {
    cout << 5;
    cout << "4 3";
    cout << "0 -3 4 2";
    cout << "5 2";
    cout << "0 -3 4 2 2";
    cout << "3 3";
    cout << "0 -3 4";
    cout << "7 2";
    cout << "0 -3 1 1 1 1 1";
    cout << "6 3";
    cout << "0 -3 4 2 1 1";
}
